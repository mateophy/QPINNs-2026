import time
import torch

from torch.optim import Adam
from torch.nn    import MSELoss

from data.synthetic.schrodinger_dataset import sample_collocation, exact_eigenstate
from src.nn.pde import schrodinger_operator, zero_potential

DTYPE = torch.float32  # mejor precisión para EDP de 2º orden

def train(model, N_f=7, N_b=5, N_0=5):

    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(DEVICE)

    # -----------------------------------------------------------------
    # Parámetros físicos y ejemplo
    # -----------------------------------------------------------------
    eq_params = model.args["eq_params"]

    example = eq_params["example"]          # "ho", "box", "barrier", ...
    L       = eq_params["L"]                # dominio espacial [0, L] o [-L, L] según el caso
    T       = eq_params["T"]                # tiempo final
    hbar    = eq_params["hbar"]
    mass    = eq_params["mass"]
    n_level = eq_params["n_level"]          # índice del nivel

    # -----------------------------------------------------------------
    # Definición del potencial según el ejemplo
    # (IMPORTANTE: reemplaza todo el bloque antiguo y quita la línea
    #  `potential_fn = 0; omega = 0`)
    # -----------------------------------------------------------------
    omega = eq_params.get("omega", 0.0)

    if example.lower() == "ho":
        # V(x) = 1/2 m ω^2 x^2 en [-L, L]
        omega = eq_params.get("omega", 1.0)

        def potential_fn(t, x, mass=mass, omega=omega):
            return 0.5 * mass * (omega**2) * x**2

    elif example.lower() in ["box", "well", "infinite_well"]:
        # Pozo infinito ideal: V=0 dentro, infinito fuera (implementado vía condiciones de frontera)
        potential_fn = zero_potential

    elif example.lower() == "barrier":
        # Barrera rectangular dentro de [0, L]
        V0            = eq_params.get("V0", 50.0)
        barrier_width = eq_params.get("barrier_width", L / 5.0)
        x_center      = eq_params.get("x_center", 0.5 * L)

        x1 = x_center - 0.5 * barrier_width
        x2 = x_center + 0.5 * barrier_width

        def potential_fn(t, x, V0=V0, x1=x1, x2=x2):
            inside = (x >= x1) & (x <= x2)
            return torch.where(inside, V0 * torch.ones_like(x), torch.zeros_like(x))

    else:
        # Caso genérico: por ahora, V=0
        potential_fn = zero_potential

    # ⛔ BORRAR la línea original:
    # potential_fn = 0; omega = 0

    # -----------------------------------------------------------------
    # Config de entrenamiento
    # -----------------------------------------------------------------
    LR           = model.args["lr"]
    PRINT_EVERY  = model.args["print_every"]
    opt          = model.optimizer if model.optimizer is not None else Adam(model.parameters(), lr=LR)
    mse          = model.loss_fn if model.loss_fn is not None else MSELoss()
    DEVICE       = model.args["device"]
    DTYPE        = torch.float32

    torch.set_default_dtype(DTYPE)
    torch.manual_seed(42)

    t0 = time.time()

    # -----------------------------------------------------------------
    # Solución exacta en t = T para comparación (malla fija)
    # -----------------------------------------------------------------
    Nx_val       = 100
    x_val_fixed  = torch.linspace(0.0 if example != "ho" else -L,
                                  L, Nx_val, device=DEVICE, dtype=DTYPE).reshape(-1, 1)
    t_val_fixed  = torch.full_like(x_val_fixed, T)

    # kwargs para exact_eigenstate (incluye V0, etc. en caso de barrera)
    exact_kwargs = dict(L=L, mass=mass, hbar=hbar, omega=omega, example=example)

    if example.lower() == "barrier":
        exact_kwargs.update(
            V0=eq_params.get("V0", 50.0),
            barrier_width=eq_params.get("barrier_width", L / 5.0),
            num_grid=eq_params.get("num_grid", 400),
        )

    with torch.no_grad():
        psi_r_exact_T, psi_i_exact_T, _ = exact_eigenstate(
            n_level, t_val_fixed, x_val_fixed, **exact_kwargs
        )
        psi_r_exact_T = psi_r_exact_T.to(DEVICE)
        psi_i_exact_T = psi_i_exact_T.to(DEVICE)

    if not hasattr(model, "l2_abs_history"):
        model.l2_abs_history = []
    if not hasattr(model, "l2_rel_history"):
        model.l2_rel_history = []

    # -----------------------------------------------------------------
    # Bucle de entrenamiento (resto de tu función casi igual)
    # -----------------------------------------------------------------
    for epoch in range(1, model.epochs + 1):

        (t_f, x_f), (t_b, x_b), (t_0, x_0) = sample_collocation(
            N_f, N_b, N_0, L=L, T=T, device=DEVICE, dtype=DTYPE, example=example
        )

        # Condición inicial analítica
        psi0_r, psi0_i, _ = exact_eigenstate(
            n_level, t_0, x_0, **exact_kwargs
        )

        opt.zero_grad()

        # PDE interior
        _, _, rR, rI = schrodinger_operator(
            model, t_f, x_f, potential_fn=potential_fn, mass=mass, hbar=hbar
        )
        loss_pde = mse(rR[:, 0:1], torch.zeros_like(rR)) + \
                   mse(rI[:, 0:1], torch.zeros_like(rI))

        # Condiciones de frontera (Dirichlet)
        psi_b   = model(torch.cat((t_b, x_b), dim=1))
        loss_bc = mse(psi_b[:, 0:1], torch.zeros_like(psi_b[:, 0:1])) + \
                  mse(psi_b[:, 1:2], torch.zeros_like(psi_b[:, 1:2]))

        # Condición inicial
        psi0    = model(torch.cat((t_0, x_0), dim=1))
        loss_ic = mse(psi0[:, 0:1], psi0_r[:, 0:1]) + \
                  mse(psi0[:, 1:2], psi0_i[:, 0:1])

        loss = loss_pde + loss_bc + loss_ic

        loss.backward()
        opt.step()

        # Evaluación L2 en t = T
        model.eval()
        with torch.no_grad():
            psi_pred = model(torch.cat((t_val_fixed, x_val_fixed), dim=1))
            err_r    = psi_pred[:, 0:1] - psi_r_exact_T[:, 0:1]
            err_i    = psi_pred[:, 1:2] - psi_i_exact_T[:, 0:1]

            l2_abs   = torch.sqrt(torch.mean(err_r**2 + err_i**2))
            ref_norm = torch.sqrt(torch.mean(
                psi_r_exact_T[:, 0:1]**2 + psi_i_exact_T[:, 0:1]**2
            )) + 1e-12
            l2_rel = l2_abs / ref_norm
            model.l2_rel_history.append(float(l2_rel))

        if epoch % PRINT_EVERY == 0 or epoch == 1:
            elapsed = time.time() - t0
            model.logger.print(
                "It: %d, Loss: %.3e, Loss_res: %.3e,  Loss_bcs: %.3e, Loss_ut_ics: %.3e, L^2_error: %3e, lr: %.3e, Time: %.2e"
                % (
                    epoch,
                    loss.item(),
                    loss_pde.item(),
                    loss_bc.item(),
                    loss_ic.item(),
                    l2_rel.item(),
                    opt.param_groups[0]["lr"],
                    elapsed,
                )
            )
            model.save_state()

        model.loss_history.append(loss.item())


